﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Problem1
{
    public class Problem1
    {
        public static IEnumerable<int> myFilter(IEnumerable<int> input)
        {
            IEnumerable<int> ret;

            IEnumerable<int> excludedNumbers;
            excludedNumbers = input.Where(x => (x % 5 == 0) && (x > 50));

            ret = input.Where(x => !excludedNumbers.Contains(x)).Select(x => x * x * x).Where(x => x % 2 != 0);

            return ret;
        }
    }

    public class Problem2
    {
        public static IEnumerable<int> myFilter(IEnumerable<int> input)
        {
            IEnumerable<int> ret;
            IEnumerable<int> excludedNumbers;

            excludedNumbers = input.Where(x => (x % 6 == 0) && (x < 42));
            ret = input.Where(x => !excludedNumbers.Contains(x)).Select(x => x * x).Where(x => x % 2 == 0);

            return ret;
        }
    }

    public class TestProblem2
    {
        public static IEnumerable<int> merge(IEnumerable<int> input1, IEnumerable<int> input2, IEnumerable<int> input3,
            IEnumerable<int> input4)
        {
            IEnumerable<int> ret;
            ret = input1.Intersect(input2).Intersect(input3).Intersect(input4).Where(x => x % 10 == 0); 

            return ret;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random(5);
            var listForProblem = Enumerable.Range(1, 100).Select(i => rnd.Next() % 101);
            var answer = Problem1.myFilter(listForProblem);
            foreach( int i in answer)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine();
            var answer2 = Problem2.myFilter(listForProblem);
            foreach(int i in answer2)
            {
                Console.WriteLine(i);
            }

            var list1 = Enumerable.Range(1, 15);
            var list2 = Enumerable.Range(2, 42).Where(i => i % 2 == 0);
            var list3 = Enumerable.Range(3, 21).Where(i => i % 2 != 0);
            var list4 = Enumerable.Range(5, 105).Where(i => i % 5 == 0);

            Console.WriteLine();
            var answer3 = TestProblem2.merge(list1, list2, list3, list4);
            foreach(int i in answer3)
            {
                Console.WriteLine(i);
            }
        }
    }
}
