﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace HomeworkPart1
{
    class Program
    {

        static int[] data = new int[10000000];
        static Thread[] thrd = new Thread[4];
        static void Main(string[] args)
        {
            //First run calc without using multithreading. Output time taken to run.
            var watch = System.Diagnostics.Stopwatch.StartNew();
            calc(0, data.Length);
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            Console.WriteLine("Sequentially, calc takes {0} milliseconds to run", elapsedMs);

            //Divide the data array into 4 parts for multithreading.
            int repsPerThread = data.Length / thrd.Length;

            //Now run calc using multithreading and split between each thread the number of repsPerThread. Output time taken to run.
            watch = System.Diagnostics.Stopwatch.StartNew();
            for( int i = 0; i < thrd.Length; i++)
            {
                int j = i;
                thrd[i] = new Thread(() => calc(j * repsPerThread, repsPerThread));
                thrd[i].Start();
            }
            for( int i = 0; i < thrd.Length; i++)
            {
                thrd[i].Join();
            }
            watch.Stop();
            elapsedMs = watch.ElapsedMilliseconds;
            Console.WriteLine("Multithreaded, calc takes {0} milliseconds to run", elapsedMs);
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
        static void calc(int startingIndex, int reps)
        {
            for(int i = startingIndex; i < reps; i++)
            {
                data[i] = (int)(Math.Atan(i) * Math.Acos(i) * Math.Cos(i) * Math.Sin(i));
            }
        }
    }
}
