﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeworkGraphics
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Pen black = new Pen(Color.Black, 7);
        

        System.Drawing.SolidBrush fillRed = new SolidBrush(Color.Red);
        System.Drawing.SolidBrush fillGreen = new SolidBrush(Color.Green);
        System.Drawing.SolidBrush fillOrange = new SolidBrush(Color.Orange);
        System.Drawing.SolidBrush fillBlue = new SolidBrush(Color.Blue);
        System.Drawing.SolidBrush fillBlack = new SolidBrush(Color.Black);



        Point top = new Point(225, 200);
        Point left = new Point(150, 275);
        Point right = new Point(250, 275);

        Point[] triangle = new Point[3] {new Point(250,200), new Point(200,275), new Point(300,275)};

        Rectangle rect = new Rectangle(100, 325, 300, 25);
        Rectangle dot1 = new Rectangle(150, 150, 1, 1);
        Rectangle dot2 = new Rectangle(350, 150, 1, 1);
        
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            g.DrawRectangle(black, rect);
            g.FillRectangle(fillBlue, rect);

            g.DrawEllipse(black, 100, 100, 100, 100);
            g.FillEllipse(fillOrange, 100, 100, 100, 100);

            g.DrawEllipse(black, 300, 100, 100, 100);
            g.FillEllipse(fillGreen, 300, 100, 100, 100);

            g.DrawPolygon(black, triangle);
            g.FillPolygon(fillRed, triangle);

            g.DrawString("It is another day in paradise", new Font("Verdana", 12, FontStyle.Bold), fillOrange, new Point(120,400));
            g.DrawString("Click mouse to continue", new Font("Verdana", 12, FontStyle.Bold), fillBlue, new Point(130,450));

            g.DrawRectangle(black, dot1);
            g.FillRectangle(fillBlack, dot1);

            g.DrawRectangle(black, dot2);
            g.FillRectangle(fillBlack, dot2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
