﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test4Problem1
{
    class Program
    {
        public static IEnumerable<int> myFilter1(IEnumerable<int> input)
        {
            IEnumerable<int> ret;
            IEnumerable<int> excludedValues;

            excludedValues = input.Where(x => (x % 7 == 0) && (x > 75));


            ret = input.Where(x => !excludedValues.Contains(x));
            ret = ret.Select(x => x * x);
            ret = ret.Where(x => x % 2 == 0);
            return ret;
        }

        public static IEnumerable<int> myFilter2(IEnumerable<int> input)
        {
            IEnumerable<int> ret2;
            IEnumerable<int> excludedValues2;

            excludedValues2 = input.Where(x => (x % 3 == 0) && (x < 35));

            ret2 = input.Where(x => !excludedValues2.Contains(x));
            ret2 = ret2.Select(x => x * x * x);
            ret2 = ret2.Where(x => x % 2 != 0);
            return ret2;
        }
        static void Main(string[] args)
        {
            Random rnd = new Random(5);

            var listForProblem = Enumerable.Range(1, 100).Select(i => rnd.Next() % 101);

            var firstResults = Program.myFilter1(listForProblem);
            Console.WriteLine(String.Join(" ", firstResults));


            var secondResults = Program.myFilter2(listForProblem);
            Console.WriteLine(String.Join(" ", secondResults));
            
        }
    }
}
