﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace Test4Problem2
{
    class Program
    {
        static string stop = "<h2>The Atari Journal</h2>";
        static string compute = "<div id=\"text\">";
        static string divEnd = "</div>";
        static void Main(string[] args)
        {
            string[] words;
            string[] outputString = new string[7];
            outputString[0] = "Magazine:";
            outputString[2] = ", Number:";
            outputString[4] = ", Date:";
            int counter = 0;
            try
            {
                WebClient wc = new WebClient();
                string htmlData = wc.DownloadString("http://rickleinecker.com/Rick-Leinecker-Magazine-Articles-and-Writing.html");

                int testIndex = htmlData.IndexOf(stop);
                int index = htmlData.IndexOf(compute);
                while( index >= 0 && index < testIndex)
                {
                    int endIndex = htmlData.IndexOf(divEnd, index);
                    string foundText = htmlData.Substring(index + compute.Length, endIndex - (index + compute.Length)).Trim();
                    words = foundText.Split(' ');
                    foreach(var word in words)
                    {
                        if(counter == 0)
                        {
                            outputString[1] = word;
                        }
                        else if(counter == 1)
                        {
                            outputString[3] = word;
                        }
                        else if(counter == 2)
                        {
                            outputString[5] = word + " ";
                        }
                        else
                        {
                            outputString[6] = word;
                        }
                        counter++;
                    }
                    Console.WriteLine();
                    foreach(var item in outputString)
                    {
                        Console.Write(item.ToString());
                    }
                    counter = 0;
                    index = endIndex;
                    index = htmlData.IndexOf(compute, index);
                }

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
        }
    }
}
