﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Test4Problem3
{
    class Program
    {
        static int numThreads;
        static int repsPerThread;
        static double[] data = new Double[10000000];
        static Thread[] thrd;
        static void Main(string[] args)
        {
            Console.WriteLine("Starting to time a sequential loop of 10,000,000 operations");
            var watch = System.Diagnostics.Stopwatch.StartNew();
            calc(0, data.Length);
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            Console.WriteLine("Time elapsed: {0} milliseconds", elapsedMs);

            Console.WriteLine("Now you will enter a number of threads to use in order to split the computing amongst threads.");
            Console.WriteLine("How many threads?");
            //Divide workload between numThreads
            numThreads = Convert.ToInt32(Console.ReadLine());
            thrd = new Thread[numThreads];
            Console.WriteLine("Starting to time a multithreaded loop of 10,000,000 operations split up amongst {0} threads", numThreads);
            repsPerThread = data.Length / numThreads;
            watch = System.Diagnostics.Stopwatch.StartNew();
            for (int i = 0; i < thrd.Length; i++)
            {
                int j = i;
                thrd[i] = new Thread(() => calc(j * repsPerThread, repsPerThread));
                thrd[i].Start();
            }
            for (int i = 0; i < thrd.Length; i++)
            {
                thrd[i].Join();
            }
            watch.Stop();
            elapsedMs = watch.ElapsedMilliseconds;
            Console.WriteLine("Multithreaded, calc takes {0} milliseconds to run", elapsedMs);
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }

        static void calc(int startIndex, int reps)
        {
            for (int i = startIndex; i < reps; i++)
            {
                data[i] = Math.Sin(i) + Math.Cos(i) + Math.Tan(i) + Math.Sinh(i) + Math.Cosh(i) + Math.Tanh(i);
            }

        }
    }
}
