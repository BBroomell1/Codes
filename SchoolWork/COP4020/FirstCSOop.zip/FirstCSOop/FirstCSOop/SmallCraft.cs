﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstCSOop
{
	class SmallCraft : IUFO
	{
		public string color { get; set; }
		public int size { get; set; }

		public void fly()
		{
			Console.WriteLine("Smallcraft is flying");
		}
		public void goToHyperspace()
		{
			Console.WriteLine("Smallcraft jumped to hyperspace");
		}
		public void land()
		{
			Console.WriteLine("Smallcraft has landed.");
		}
	}
}
