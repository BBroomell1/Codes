﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstCSOop
{
	class Bird: Animal
	{
		public void sing()
		{
			Console.WriteLine("The bird is singing");
		}
		public void wash()
		{
			Console.WriteLine("Bird is getting a bath");
		}
		public void turnAround()
		{
			Console.WriteLine("the bird turned around.");
		}
	}
}
