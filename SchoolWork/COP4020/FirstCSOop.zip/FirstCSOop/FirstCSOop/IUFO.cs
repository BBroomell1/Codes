﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstCSOop
{
	interface IUFO
	{
		string color { get; set; }
		int size { get; set; }

		void fly();
		void goToHyperspace();
		void land();

	}
}
