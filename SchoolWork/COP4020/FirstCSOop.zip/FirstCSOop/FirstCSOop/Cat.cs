﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstCSOop
{
	class Cat: Animal
	{
		public void sing()
		{
			Console.WriteLine("The Cat is singing... i guess");
		}
		public void wash()
		{
			Console.WriteLine("The cat is bathing");
		}
		public void turnAround()
		{
			Console.WriteLine("The cat turned around");
		}
	}
}
