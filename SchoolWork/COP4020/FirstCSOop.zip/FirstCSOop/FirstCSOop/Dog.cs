﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstCSOop
{
	class Dog: Animal
	{
		public void sing()
		{
			Console.WriteLine("The dog is barking");
		}
		public void wash()
		{
			Console.WriteLine("Dog is getting a bath");
		}
		public void turnAround()
		{
			Console.WriteLine("The dog turned around");
		}
	}
}
