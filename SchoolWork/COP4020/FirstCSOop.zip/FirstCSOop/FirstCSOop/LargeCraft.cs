﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstCSOop
{
	class LargeCraft : IUFO
	{
		public string color { get; set; }
		public int size { get; set; } 

		public void fly()
		{
			Console.WriteLine("Largecraft is flying");
		}
		public void goToHyperspace()
		{
			Console.WriteLine("Largecraft jumped to hyperspace");
		}
		public void land()
		{
			Console.WriteLine("Largecraft has landed.");
		}
	}
}
