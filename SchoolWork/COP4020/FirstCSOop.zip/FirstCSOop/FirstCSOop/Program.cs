﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstCSOop
{
	class Program
	{
		static void Main(string[] args)
		{
			//New instances of each class.
			Dog puppy = new Dog();
			Cat kitten = new Cat();
			Bird tweety = new Bird();
			SmallCraft sc = new SmallCraft();
			LargeCraft lc = new LargeCraft();
			BossCraft bc = new BossCraft();

			//Methods for Dog
			puppy.sing();
			puppy.wash();
			puppy.turnAround();
			puppy.move();
			puppy.sleep();
			puppy.eat();

			//Methods for Cat
			kitten.sing();
			kitten.wash();
			kitten.turnAround();
			kitten.move();
			kitten.sleep();
			kitten.eat();

			//Methods for Bird
			tweety.sing();
			tweety.wash();
			tweety.turnAround();
			tweety.move();
			tweety.sleep();
			tweety.eat();


			//Methods for Smallcraft
			sc.fly();
			sc.goToHyperspace();
			sc.land();

			//Methods for Largecraft
			lc.fly();
			lc.goToHyperspace();
			lc.land();

			//Methods for Bosscraft
			bc.fly();
			bc.goToHyperspace();
			bc.land();

		}
	}
}
