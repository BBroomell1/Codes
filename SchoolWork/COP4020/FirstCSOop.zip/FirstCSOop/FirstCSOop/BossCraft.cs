﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstCSOop
{
	class BossCraft : IUFO
	{
		public string color { get; set; } 
		public int size { get; set; }
		public void fly()
		{
			Console.WriteLine("Bosscraft is flying");
		}
		public void goToHyperspace()
		{
			Console.WriteLine("Bosscraft jumped to hyperspace");
		}
		public void land()
		{
			Console.WriteLine("Bosscraft has landed.");
		}
	}
}
