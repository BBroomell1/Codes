﻿namespace HomeworkPart2
{
    partial class COP4020Homework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbConvertFrom = new System.Windows.Forms.ComboBox();
            this.lnlTempIn = new System.Windows.Forms.Label();
            this.txtTempIn = new System.Windows.Forms.TextBox();
            this.lblConvertFrom = new System.Windows.Forms.Label();
            this.btnConvert = new System.Windows.Forms.Button();
            this.cmbConvertTo = new System.Windows.Forms.ComboBox();
            this.lblConvertTo = new System.Windows.Forms.Label();
            this.lblTempOut = new System.Windows.Forms.Label();
            this.txtTempOut = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cmbConvertFrom
            // 
            this.cmbConvertFrom.BackColor = System.Drawing.SystemColors.Window;
            this.cmbConvertFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.cmbConvertFrom.FormattingEnabled = true;
            this.cmbConvertFrom.Location = new System.Drawing.Point(12, 140);
            this.cmbConvertFrom.Name = "cmbConvertFrom";
            this.cmbConvertFrom.Size = new System.Drawing.Size(180, 39);
            this.cmbConvertFrom.TabIndex = 0;
            // 
            // lnlTempIn
            // 
            this.lnlTempIn.AutoSize = true;
            this.lnlTempIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lnlTempIn.Location = new System.Drawing.Point(291, 18);
            this.lnlTempIn.Name = "lnlTempIn";
            this.lnlTempIn.Size = new System.Drawing.Size(237, 31);
            this.lnlTempIn.TabIndex = 1;
            this.lnlTempIn.Text = "Input Temperature";
            // 
            // txtTempIn
            // 
            this.txtTempIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtTempIn.Location = new System.Drawing.Point(357, 52);
            this.txtTempIn.Name = "txtTempIn";
            this.txtTempIn.Size = new System.Drawing.Size(100, 38);
            this.txtTempIn.TabIndex = 2;
            // 
            // lblConvertFrom
            // 
            this.lblConvertFrom.AutoSize = true;
            this.lblConvertFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblConvertFrom.Location = new System.Drawing.Point(12, 106);
            this.lblConvertFrom.Name = "lblConvertFrom";
            this.lblConvertFrom.Size = new System.Drawing.Size(188, 31);
            this.lblConvertFrom.TabIndex = 3;
            this.lblConvertFrom.Text = "Convert From:";
            // 
            // btnConvert
            // 
            this.btnConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnConvert.Location = new System.Drawing.Point(343, 122);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(125, 73);
            this.btnConvert.TabIndex = 4;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // cmbConvertTo
            // 
            this.cmbConvertTo.BackColor = System.Drawing.SystemColors.Window;
            this.cmbConvertTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.cmbConvertTo.FormattingEnabled = true;
            this.cmbConvertTo.Location = new System.Drawing.Point(625, 140);
            this.cmbConvertTo.Name = "cmbConvertTo";
            this.cmbConvertTo.Size = new System.Drawing.Size(180, 39);
            this.cmbConvertTo.TabIndex = 5;
            // 
            // lblConvertTo
            // 
            this.lblConvertTo.AutoSize = true;
            this.lblConvertTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblConvertTo.Location = new System.Drawing.Point(641, 106);
            this.lblConvertTo.Name = "lblConvertTo";
            this.lblConvertTo.Size = new System.Drawing.Size(157, 31);
            this.lblConvertTo.TabIndex = 6;
            this.lblConvertTo.Text = "Convert To:";
            // 
            // lblTempOut
            // 
            this.lblTempOut.AutoSize = true;
            this.lblTempOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblTempOut.Location = new System.Drawing.Point(291, 231);
            this.lblTempOut.Name = "lblTempOut";
            this.lblTempOut.Size = new System.Drawing.Size(258, 31);
            this.lblTempOut.TabIndex = 7;
            this.lblTempOut.Text = "Output Temperature";
            // 
            // txtTempOut
            // 
            this.txtTempOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtTempOut.Location = new System.Drawing.Point(357, 265);
            this.txtTempOut.Name = "txtTempOut";
            this.txtTempOut.Size = new System.Drawing.Size(100, 38);
            this.txtTempOut.TabIndex = 8;
            // 
            // COP4020Homework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(817, 354);
            this.Controls.Add(this.txtTempOut);
            this.Controls.Add(this.lblTempOut);
            this.Controls.Add(this.lblConvertTo);
            this.Controls.Add(this.cmbConvertTo);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.lblConvertFrom);
            this.Controls.Add(this.txtTempIn);
            this.Controls.Add(this.lnlTempIn);
            this.Controls.Add(this.cmbConvertFrom);
            this.Name = "COP4020Homework";
            this.Text = "Temperature Converter";
            this.Load += new System.EventHandler(this.COP4020Homework_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbConvertFrom;
        private System.Windows.Forms.Label lnlTempIn;
        private System.Windows.Forms.TextBox txtTempIn;
        private System.Windows.Forms.Label lblConvertFrom;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.ComboBox cmbConvertTo;
        private System.Windows.Forms.Label lblConvertTo;
        private System.Windows.Forms.Label lblTempOut;
        private System.Windows.Forms.TextBox txtTempOut;
    }
}

