﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeworkPart2
{
    public partial class COP4020Homework : Form
    {
        public COP4020Homework()
        {
            InitializeComponent();
        }

        static string[] conversions = { "Farenheit", "Celsius", "Kelvin" };
        private void COP4020Homework_Load(object sender, EventArgs e)
        {
            foreach ( string type in conversions)
            {
                cmbConvertFrom.Items.Add(type);
                cmbConvertTo.Items.Add(type);
            }
            cmbConvertFrom.SelectedIndex = 0;
            cmbConvertTo.SelectedIndex = 0;
        }

        string cleanUp(TextBox obj)
        {
            return obj.Text.Trim().Replace(",", "");
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double temperature;
            double result;
            try
            {
                temperature = Convert.ToDouble(cleanUp(txtTempIn));
            }
            catch
            {
                MessageBox.Show("Input temperature value not valid.");
                return;
            }


            //Calculate the Temperature In to the Temperature Out
            if( cmbConvertFrom.SelectedIndex == 0) 
            {
                //Input Temperature is Farenheit
                if( cmbConvertTo.SelectedIndex == 0)
                {
                    //Farenheit to Farenheit
                    result = temperature;
                    txtTempOut.Text = string.Format(result.ToString());
                }
                else if( cmbConvertTo.SelectedIndex == 1)
                {
                    //Farenheit to Celsius
                    result = ((temperature - 32) * (5.0 / 9.0));
                    txtTempOut.Text = string.Format(result.ToString());
                }
                else if( cmbConvertTo.SelectedIndex == 2)
                {
                    //Farenheit to Kelvin
                    result = ((temperature + 459.67) * (5.0 / 9.0));
                    txtTempOut.Text = string.Format(result.ToString());
                }
            }
            else if(cmbConvertFrom.SelectedIndex == 1)
            {
                //Input Temperature is Celsius
                if (cmbConvertTo.SelectedIndex == 0)
                {
                    //Celsius to Farenheit
                    result = ((temperature * (9.0 / 5.0)) + 32); 
                    txtTempOut.Text = string.Format(result.ToString());
                }
                else if (cmbConvertTo.SelectedIndex == 1)
                {
                    //Celsius to Celsius
                    result = temperature;
                    txtTempOut.Text = string.Format(result.ToString());
                }
                else if (cmbConvertTo.SelectedIndex == 2)
                {
                    //Celsius to Kelvin
                    result = (temperature + 273.15);
                    txtTempOut.Text = string.Format(result.ToString());
                }
            }
            else if(cmbConvertFrom.SelectedIndex == 2)
            {
                //Input Temperature is Kelvin
                if (cmbConvertTo.SelectedIndex == 0)
                {
                    //Kelvin to Farenheit
                    result = ((temperature * (9.0 / 5.0)) - 459.67);
                    txtTempOut.Text = string.Format(result.ToString());
                }
                else if (cmbConvertTo.SelectedIndex == 1)
                {
                    //Kelvin to Celsius
                    result = temperature - 273.15;
                    txtTempOut.Text = string.Format(result.ToString());
                }
                else if (cmbConvertTo.SelectedIndex == 2)
                {
                    //Kelvin to Kelvin
                    result = temperature;
                    txtTempOut.Text = string.Format(result.ToString());
                }
            }
        }
    }
}
