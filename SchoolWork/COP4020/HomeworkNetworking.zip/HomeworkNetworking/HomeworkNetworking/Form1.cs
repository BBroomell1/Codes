﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeworkNetworking
{
    public partial class Form1 : Form
    {

        public IWebDriver driver;

        public object PaneText { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void Open_Browser()
        {
            var driverService = ChromeDriverService.CreateDefaultService();
            driverService.HideCommandPromptWindow = true;

            driver = new ChromeDriver(driverService);

            try
            {
                driver.Navigate().GoToUrl("http://rickleinecker.com/index.html");
            }
            catch
            {
                throw;
            }


        }

        private void Find_Data()
        {
            IList<IWebElement> searchElements = driver.FindElements(By.ClassName("PaneText"));
            foreach (IWebElement i in searchElements)
            {
                HtmlAgilityPack.HtmlDocument htmlDocument = new HtmlAgilityPack.HtmlDocument();
                var text = i.GetAttribute("innerHTML");
                htmlDocument.LoadHtml(text);
                txtResults.AppendText(text);
                txtResults.AppendText("\t\r");
            }
        }




        private void btnOpenBrowser_Click(object sender, EventArgs e)
        {
            Open_Browser();
        }

        private void btnEXIT_Click(object sender, EventArgs e)
        {
            driver.Quit();
        }

        private void btnScrape_Click(object sender, EventArgs e)
        {
            Find_Data();
        }
    }
}
