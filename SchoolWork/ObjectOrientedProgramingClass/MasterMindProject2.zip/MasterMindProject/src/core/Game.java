/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author Brandon
 */
public class Game implements IGame{
    private int attempt;
    private Codebreaker codebreaker;
    private Codemaker codemaker;

    

   
    /**
     * @return the attempt
     */
    public int getAttempt() {
        return attempt;
    }

    /**
     * @param attempt the attempt to set
     */
    public void setAttempt(int attempt) {
        this.attempt = attempt;
    }

    /**
     * @return the codebreaker
     */
    public Codebreaker getCodebreaker() {
        return codebreaker;
    }

    /**
     * @param codebreaker the codebreaker to set
     */
    public void setCodebreaker(Codebreaker codebreaker) {
        this.codebreaker = codebreaker;
    }

    /**
     * @return the codemaker
     */
    public Codemaker getCodemaker() {
        return codemaker;
    }

    /**
     * @param codemaker the codemaker to set
     */
    public void setCodemaker(Codemaker codemaker) {
        this.codemaker = codemaker;
    }
    
    public Game(){
        codebreaker = new Codebreaker();
        codemaker = new Codemaker();
    }
    @Override
    public void play() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
