/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;


import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import static constants.Constants.codeColors;
import static constants.Constants.COLORS;
import static constants.Constants.MAX_PEGS;
/**
 *
 * @author Brandon
 */
public class Codemaker implements ICodemaker{
//VARIABLES
    private Set<Color> secretCode;
    private ArrayList<Color> codeMakerResponse;

    
   
    //GETTERS AND SETTERS
   /**
     * @return the secretCode
     */
    public Set<Color> getSecretCode() {
        return secretCode;
    }

    /**
     * @param secretCode the secretCode to set
     */
    public void setSecretCode(Set<Color> secretCode) {
        this.secretCode = secretCode;
    }

    /**
     * @return the codeMakerResponse
     */
    public ArrayList<Color> getCodeMakerResponse() {
        return codeMakerResponse;
    }

    /**
     * @param codeMakerResponse the codeMakerResponse to set
     */
    public void setCodeMakerResponse(ArrayList<Color> codeMakerResponse) {
        this.codeMakerResponse = codeMakerResponse;
    }

    
//CONSTRUCTOR
     public Codemaker() {
//INITIALIZE VARIABLES
        secretCode = new HashSet();
        codeMakerResponse = new ArrayList();
       
     
        generateSecretCode();
      
    }

    @Override
    public void generateSecretCode() {
//RANDOM INSTANCE
       Random rand = new Random();
//GENERATE 4 RANDOM COLORS AND ADD THEM TO secretCode 
     do{
         int number = rand.nextInt(COLORS);
         Color tempColor;
         tempColor = codeColors.get(number);
         secretCode.add(tempColor);
     }while(secretCode.size() < MAX_PEGS);
     
//PRINT OUT EACH COLOR USING AN ENHANCED FOR LOOP
     for(Color color: secretCode){
        System.out.println(color);
    }
    }
    @Override
    public void checkAttemptCode() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    

    
    
    
}
