/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.awt.Color;
import java.util.ArrayList;

/**
 *
 * @author Brandon
 */
public class Codebreaker implements ICodebreaker{
    private ArrayList<Color> codebreakerAttempt;

    /**
     * @return the codebreakerAttempt
     */
    public ArrayList<Color> getCodebreakerAttempt() {
        return codebreakerAttempt;
    }

    /**
     * @param codebreakerAttempt the codebreakerAttempt to set
     */
    public void setCodebreakerAttempt(ArrayList<Color> codebreakerAttempt) {
        this.codebreakerAttempt = codebreakerAttempt;
    }

    /**
     *
     */
    public Codebreaker() {
        codebreakerAttempt = new ArrayList<Color>();
        
    }

    @Override
    public void checkCode(ArrayList<Color> attempt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
   
}
