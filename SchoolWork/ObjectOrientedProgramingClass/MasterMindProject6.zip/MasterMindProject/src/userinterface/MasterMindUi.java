/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import core.Game;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 *
 * @author Brandon
 */
public class MasterMindUi {
    
    Game game;
    CodebreakerUi codebreakerUi;
    CodemakerUi codemakerUi;
    JFrame frame;
    JMenuBar menuBar;
    JMenu gameMenu;
    JMenu helpMenu;
    JMenuItem newGameMenuItem;
    JMenuItem exitMenuItem;
    JMenuItem aboutMenuItem;
    JMenuItem rulesMenuItem;
    
    public MasterMindUi(Game game)
    {
        this.game = game;
        codebreakerUi = new CodebreakerUi(game.getCodebreaker());
        codemakerUi = new CodemakerUi(game.getCodemaker());
        initComponents();
    }
    
    public void initComponents()
    {
        
        
    //FRAME
        frame = new JFrame();
        frame.setSize(1000, 1000);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        
        
    //JMENU BAR
        menuBar = new JMenuBar();
        
        //CREATE THE GAME MENU WITH NEW GAME AND EXIT GAME
            gameMenu = new JMenu("Game");
                menuBar.add(gameMenu);
                        newGameMenuItem = new JMenuItem("New Game");
                            newGameMenuItem.addActionListener(new NewGameListener());
                            gameMenu.add(newGameMenuItem);
                        exitMenuItem  = new JMenuItem("Exit Game");
                            exitMenuItem.addActionListener(new ExitListener());
                            gameMenu.add(exitMenuItem);
                            
                            
        //CREATE THE HELP MENU WITH ABOUT AND RULES        
            helpMenu = new JMenu("Help");
                menuBar.add(helpMenu);
                    aboutMenuItem = new JMenuItem("About");
                        aboutMenuItem.addActionListener(new AboutListener()); 
                        helpMenu.add(aboutMenuItem);
                    rulesMenuItem = new JMenuItem("Rules"); 
                        rulesMenuItem.addActionListener(new RulesListener());
                        helpMenu.add(rulesMenuItem);
                
 
    //SET MENU TO FRAME
        frame.setJMenuBar(menuBar);
    
    //ADD COMDEMAKERUI JPANELS
        frame.add(codemakerUi.getCodemakerResponse(), BorderLayout.EAST);
        frame.add(codemakerUi.getSecretCode(), BorderLayout.NORTH);
   //ADD CODEBREAKERUI JPANELS    
        frame.add(codebreakerUi.getCodebreakerAttempt(), BorderLayout.WEST);
        frame.add(codebreakerUi.getCodebreakerColors(), BorderLayout.SOUTH);
    
        
        
    //SET VISIBLE TO TRUE    
        frame.setVisible(true);
        
    
    }
    
    private class ExitListener implements ActionListener
    {

        @Override
        public void actionPerformed(ActionEvent ae) {
            int response = JOptionPane.showConfirmDialog(null, "Are You Sure You Want To Exit?", 
                    "Exit?", JOptionPane.YES_NO_OPTION);
            
            if (response == JOptionPane.YES_OPTION)
                System.exit(0);        }
        
    }
    
    private class AboutListener implements ActionListener
    {

        @Override
        public void actionPerformed(ActionEvent ae) {
            JOptionPane.showMessageDialog(frame, "Mastermind Version 1.0\nBrandon Broomell\n10/25/2017");
        }
        
    }
    
    private class RulesListener implements ActionListener
    {

        @Override
        public void actionPerformed(ActionEvent ae) {
            JOptionPane.showMessageDialog(frame, "Step 1: The codemaker selects a four color secret code, in any order, no duplicate colors.\n\n"
                    + "Step 2: The codebreaker places a guess in the bottom row, no duplicate colors.\n\n"
                    + "Step 3: The codemaker gives feedback next to each guess row with four pegs\n"
                    + "~Each red peg means that one of the guessed colors is correct, and is in the right location.\n"
                    + "~Each white peg means that one of th guessed colors is correct, but in the wrong location.\n\n"
                    + "Step 4: Repeat with the net row, unless the secret code was guessed.\n\n"
                    + "Step 5: Continue until the secret code is guessed or there are no more guesses left, there are 10 attempts.");
        }
        
    }
    
    private class NewGameListener implements ActionListener
    {

        @Override
        public void actionPerformed(ActionEvent ae) {
             codebreakerUi.clearBoard();
        }
        
    }
}
