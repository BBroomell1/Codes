/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import constants.Constants;
import static constants.Constants.codeColors;
import core.Codebreaker;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 *
 * @author Brandon
 */
public class CodebreakerUi {
    
    JPanel codebreakerAttempt;
    JPanel codebreakerColors;
    Codebreaker codebreaker;
    RoundButton[] buttons;
    RoundButton[][] attempts;
    Color colorSelected;
    
    public CodebreakerUi(Codebreaker codebreaker)
            {
                this.codebreaker = codebreaker;
                initComponents();
            }
    
    public void initComponents()
    {
        
        
    //CODEBREAKER ATTEMPT JPANEL 
    codebreakerAttempt = new JPanel();
        codebreakerAttempt.setMinimumSize(new Dimension(600,200));
        codebreakerAttempt.setPreferredSize(new Dimension(600,200));
        codebreakerAttempt.setBorder(BorderFactory.createTitledBorder("Codebreaker Attempt"));
        codebreakerAttempt.setLayout(new GridLayout(10, 4));
        attempts = new RoundButton[10][4];
        for(int i = 0; i < 10; i++)
        {
            for(int j = 0; j < 4; j++)
            {
                attempts[i][j] = new RoundButton();
                if(i != 9)
                {
                    attempts[i][j].setEnabled(false);
                }
                attempts[i][j].putClientProperty("row", i);
                codebreakerAttempt.add(attempts[i][j]);
                
            }
        }
        
    //CODEBREAKER COLORS JPANEL 
    codebreakerColors = new JPanel();
        codebreakerColors.setMinimumSize(new Dimension(200,200));
        codebreakerColors.setPreferredSize(new Dimension(200,200));
        codebreakerColors.setBorder(BorderFactory.createTitledBorder("Codebreaker Colors"));
        codebreakerColors.setLayout(new FlowLayout());
        //Add the RoundButtons to the JPanel
        buttons = new RoundButton[Constants.COLORS];
        int counter = 0;
        for (RoundButton button : buttons) 
        {			
            // create the buttons
            button = new RoundButton();
            Color color = Constants.codeColors.get(counter);
            button.setBackground(color);
            button.putClientProperty("color", color);
            
            // set the tooltip
            if(color == Color.BLUE)
                button.setToolTipText("BLUE");
            else if(color == Color.BLACK)
                button.setToolTipText("BLACK");
            else if(color == Color.GREEN)
                button.setToolTipText("GREEN");
            else if(color == Color.ORANGE)
                button.setToolTipText("ORANGE");
            else if(color == Color.PINK)
                button.setToolTipText("PINK");
            else if(color == Color.RED)
                button.setToolTipText("RED");            
            else if(color == Color.YELLOW)
                button.setToolTipText("YELLOW");
            else if(color == Color.WHITE)
                button.setToolTipText("WHITE");
                        
            // add an ActionListener
            
            
            // add button to JPanel using FlowLayout
            codebreakerColors.add(button);
            
            // increment the counter
            counter++;
        }	

    }
    public JPanel getCodebreakerAttempt() {
        return codebreakerAttempt;
    }

    public JPanel getCodebreakerColors() {
        return codebreakerColors;
    }
  
    public void clearBoard()
    {
        for(int i = 0; i < 10; i++)
                {
                    for(int j = 0; j < 4; j++)
                            {
                              attempts[i][j].setBackground(null);
                              if(i == 9)
                              {
                                  attempts[i][j].setEnabled(true);
                              }
                              else 
                              {
                                  attempts[i][j].setEnabled(false);
                              }
                            }
                }
        codebreakerAttempt.removeAll();
    }
    
    private void enableDisableButtons(int row)
    {
        for(int j = 0; j < 4; j++)
        {
            attempts[row][j].setEnabled(false);
        }
        if(row != 0)
        {
            for(int j = 0; j < 4; j++)
            {
                attempts[row+ 1][j].setEnabled(true);
            }
        }
        codebreakerAttempt.removeAll();
    }
}
