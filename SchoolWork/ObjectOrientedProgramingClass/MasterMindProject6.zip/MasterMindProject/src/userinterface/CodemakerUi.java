/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import constants.Constants;
import core.Codemaker;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 *
 * @author Brandon
 */
public class CodemakerUi {
    JPanel codemakerResponse;
    JPanel secretCode;
    Codemaker codemaker;
    JLabel[] secretLabels;
    JLabel[][] responseLabels;
    ImageIcon question;
    
    public CodemakerUi(Codemaker codemaker)
    {
        this.codemaker = codemaker;
        initComponents();
    }
    
    public void initComponents()
    {
        
        
    //CODEMAKER RESPONSE JPANEL
        codemakerResponse = new JPanel();
            codemakerResponse.setBorder(BorderFactory.createTitledBorder("Codemaker Response"));
            codemakerResponse.setMinimumSize(new Dimension(375, 200));
            codemakerResponse.setPreferredSize(new Dimension(375, 200));
            responseLabels = new JLabel[10][4];
            for(int i = 0; i < 10; i ++)
            {
                for(int j = 0; j < 4; j++)
                {
                    responseLabels[i][j] = new JLabel();
                    responseLabels[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                    codemakerResponse.add(responseLabels[i][j]);
                }
            }
        
    
    //SECRET CODE JPANEL
        secretCode = new JPanel();
            secretCode.setBorder(BorderFactory.createTitledBorder("Secret Code"));
            secretCode.setMinimumSize(new Dimension(200, 200));
            secretCode.setPreferredSize(new Dimension(200, 200));
            secretCode.setLayout(new FlowLayout());
            secretLabels = new JLabel[Constants.MAX_PEGS];
            question = new ImageIcon( getClass().getResource("question.jpg"));
            for(int i = 0; i < 4; i++)
            {
                secretLabels[i] = new JLabel();
                ImageIcon temp = new ImageIcon();
                temp = imageResize(question);
                secretLabels[i].setIcon(question);
                secretCode.add(secretLabels[i]);
            }
            JButton buttonCheck = new JButton("Check");
            secretCode.add(buttonCheck);
    }
    
   private ImageIcon imageResize(ImageIcon icon)
    {
        Image image = icon.getImage();
        Image newImage = image.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newImage);
        return icon;
    }


    public JPanel getCodemakerResponse() {
        return codemakerResponse;
    }

    public JPanel getSecretCode() {
        return secretCode;
    }
    
}
