/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import static constants.Constants.MAX_PEGS;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Brandon
 */
public class Codebreaker implements ICodebreaker {

    private ArrayList<Color> codebreakerAttempt;

    
    /**
     *
     */
    public Codebreaker() {
        codebreakerAttempt = new ArrayList<>();

    }

   

    private void consoleAttempt() {
        codebreakerAttempt.removeAll(codebreakerAttempt);
        Scanner input;
        input = new Scanner(System.in);
        int i = 0;

        System.out.println("Enter your colors from left to right \n" + "Use BLUE, BLACK, ORANGE, WHITE, YELLOW, RED, GREEN, PINK");
        do {
            String tempInput = input.next();
            String inputColor = tempInput.toUpperCase();

            if (null == inputColor) {
                System.out.println("Invalid color choice, try again");
            }            
            else switch (inputColor) {
            
                case "BLUE":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.blue);
                    i++;
                    System.out.println("Enter next color.");
                    break;
            //break
                case "BLACK":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.black);
                    i++;
                    System.out.println("Enter next color.");
                    break;
            //break
                case "ORANGE":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.orange);
                    i++;
                    System.out.println("Enter next color.");
                    break;
            //break
                case "WHITE":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.white);
                    i++;
                    System.out.println("Enter next color.");
                    break;
            //break
                case "YELLOW":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.yellow);
                    i++;
                    System.out.println("Enter next color.");
                    break;
            //break
                case "RED":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.red);
                    i++;
                    System.out.println("Enter next color.");
                    break;
            //break
                case "GREEN":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.green);
                    i++;
                    System.out.println("Enter next color.");
                    break;
            //break
                case "PINK":
                    System.out.println("The selected color was: \n" + inputColor);
                    codebreakerAttempt.add(Color.pink);
                    i++;
                    System.out.println("Enter next color.");
                    break;
                default:
                    System.out.println("Invalid color choice, try again");
                    break;
            }
        } while (i < MAX_PEGS); //END WHILE LOOP
        
        for(Color color: codebreakerAttempt){
        System.out.println(color);
        }
    }//END METHOD
    
/**
     * @return the codebreakerAttempt
     */
    public ArrayList<Color> getCodebreakerAttempt() {
        //consoleAttempt();
        return codebreakerAttempt;
    }

    /**
     * @param codebreakerAttempt the codebreakerAttempt to set
     */
    public void setCodebreakerAttempt(ArrayList<Color> codebreakerAttempt) {
        this.codebreakerAttempt = codebreakerAttempt;
    }
    
 @Override
    public void checkCode(ArrayList<Color> attempt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void removeAll()
    {
        codebreakerAttempt.removeAll(codebreakerAttempt);
    }
    
}//END CLASS CODEBREAKER
