/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;


import constants.Constants;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import static constants.Constants.MAX_PEGS;
import java.util.List;
/**
 *
 * @author Brandon
 */
public class Codemaker implements ICodemaker{
//VARIABLES
    private Set<Color> secretCode;
    private ArrayList<Color> codeMakerResponse;
    private boolean codeGuessed;

    
   
    
    
//CONSTRUCTOR
     public Codemaker() {
//INITIALIZE VARIABLES
        codeGuessed = false;
        secretCode = new HashSet();
        codeMakerResponse = new ArrayList();
       
     
        generateSecretCode();
      
    }

    @Override
    public void generateSecretCode() {
//RANDOM INSTANCE
       Random rand = new Random();
//GENERATE 4 RANDOM COLORS AND ADD THEM TO secretCode 
     do{
         int number = rand.nextInt(Constants.COLORS);
         Color tempColor;
         tempColor = Constants.codeColors.get(number);
         secretCode.add(tempColor);
     }while(secretCode.size() < MAX_PEGS);
     System.out.println("Generated the secret code");
     
//PRINT OUT EACH COLOR USING AN ENHANCED FOR LOOP
     for(Color color: secretCode){
        System.out.println(color.toString());
        }
    }
    @Override
    public void checkAttemptedCode(ArrayList<Color> attempt) {
        
/* I AM HAVING TROUBLE WITH THIS PART HERE, SPECIFICALLY CONVERTING THE SECRET CODE SET MEMBER
        VARIABLE TO AN ARRAYLIST OBJECT.
        */

       // correct color in correct position is a red peg
        int redPegs = 0;
        // correct color in the wrong position is a white peg
        int whitePegs = 0;
        // incorrect color has no peg 
        // keep track of which pegs we already counted
        Set<Color> countedPegs = new HashSet();
        
        System.out.println("Codemaker is checking codebreaker attempt");
        
        // convert the Set to an ArrayList
        List<Color> secretList = new ArrayList<>(secretCode);
        
        // is it an exact match?            
        if(secretList.equals(attempt))
        {
            redPegs += 4; 
            whitePegs = 0;
            System.out.println("You guessed it!");
        }
        // not an exact match, is it even in the secret code
        else
        {                     
            // check for correct color and correct position
            for(int peg = 0; peg < Constants.MAX_PEGS; peg++)
            {
                if(secretList.get(peg) == attempt.get(peg))
                {
                    System.out.println("Found correct color in correct position!");
                    // correct peg in correct location, add a red peg
                    redPegs++;
                    countedPegs.add(attempt.get(peg));
                }
            }
            
            // check for any match
            for(Color color : attempt)
            {
                // check if any of the colors are correct
                if(secretList.contains(color))       
                {
                    for(int peg = 0; peg < Constants.MAX_PEGS; peg++)
                    {

                        if((secretList.get(peg) != attempt.get(peg)) && 
                           (secretList.contains(attempt.get(peg)))  &&
                           !countedPegs.contains(attempt.get(peg))) 
                        {
                            System.out.println("Found correct color in wrong position");
                            // add a white peg
                            whitePegs++;
                            countedPegs.add(attempt.get(peg));
                        }
                    }
                }
            }
        }
        
        evaluatePegs(redPegs, whitePegs);
    }

    private void evaluatePegs(int red, int white)
    {
        // clear the codemakerResponse
        codeMakerResponse.removeAll(codeMakerResponse);
        
        System.out.println("Red pegs " + red + " white pegs " + white);
        
        if(red == Constants.MAX_PEGS)
        {
            codeGuessed = true;
        }
        
        for(int r = 0; r < red; r++)
        {
            codeMakerResponse.add(Color.RED);
        }
        
        for(int w = 0; w < white; w++)
        {
            codeMakerResponse.add(Color.WHITE);
        }
    }
    
//GETTERS AND SETTERS
   /**
     * @return the secretCode
     */
    public Set<Color> getSecretCode() {
        return secretCode;
    }

    /**
     * @param secretCode the secretCode to set
     */
    public void setSecretCode(Set<Color> secretCode) {
        this.secretCode = secretCode;
    }

    /**
     * @return the codeMakerResponse
     */
    public ArrayList<Color> getCodeMakerResponse() {
        return codeMakerResponse;
    }

    /**
     * @param codeMakerResponse the codeMakerResponse to set
     */
    public void setCodeMakerResponse(ArrayList<Color> codeMakerResponse) {
        this.codeMakerResponse = codeMakerResponse;
    }
    
    /**
     * @return the codeGuessed
     */
    public boolean isCodeGuessed() {
        return codeGuessed;
    }

    /**
     * @param codeGuessed the codeGuessed to set
     */
    public void setCodeGuessed(boolean codeGuessed) {
        this.codeGuessed = codeGuessed;
    }
    


}//END CLASS
