/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import core.Codemaker;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 *
 * @author Brandon
 */
public class CodemakerUi {
    JPanel codemakerResponse;
    JPanel secretCode;
    Codemaker codemaker;
    
    public CodemakerUi(Codemaker codemaker)
    {
        this.codemaker = codemaker;
        initComponents();
    }
    
    public void initComponents()
    {
        
        
    //CODEMAKER RESPONSE JPANEL
        codemakerResponse = new JPanel();
            codemakerResponse.setBorder(BorderFactory.createTitledBorder("Codemaker Response"));
            codemakerResponse.setMinimumSize(new Dimension(375, 200));
            codemakerResponse.setPreferredSize(new Dimension(375, 200));
        
    
    //SECRET CODE JPANEL
        secretCode = new JPanel();
            secretCode.setBorder(BorderFactory.createTitledBorder("Secret Code"));
            secretCode.setMinimumSize(new Dimension(200, 200));
            secretCode.setPreferredSize(new Dimension(200, 200));
            
    }

    public JPanel getCodemakerResponse() {
        return codemakerResponse;
    }

    public JPanel getSecretCode() {
        return secretCode;
    }
    
}
