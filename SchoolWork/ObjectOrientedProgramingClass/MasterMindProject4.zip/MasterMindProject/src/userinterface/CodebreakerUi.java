/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import core.Codebreaker;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 *
 * @author Brandon
 */
public class CodebreakerUi {
    
    JPanel codebreakerAttempt;
    JPanel codebreakerColors;
    Codebreaker codebreaker;
    
    public CodebreakerUi(Codebreaker codebreaker)
            {
                this.codebreaker = codebreaker;
                initComponents();
            }
    
    public void initComponents()
    {
        
        
    //CODEBREAKER ATTEMPT JPANEL 
    codebreakerAttempt = new JPanel();
        codebreakerAttempt.setMinimumSize(new Dimension(600,200));
        codebreakerAttempt.setPreferredSize(new Dimension(600,200));
        codebreakerAttempt.setBorder(BorderFactory.createTitledBorder("Codebreaker Attempt"));
        
    //CODEBREAKER COLORS JPANEL 
    codebreakerColors = new JPanel();
        codebreakerColors.setMinimumSize(new Dimension(200,200));
        codebreakerColors.setPreferredSize(new Dimension(200,200));
        codebreakerColors.setBorder(BorderFactory.createTitledBorder("Codebreaker Colors")); 
    }
    public JPanel getCodebreakerAttempt() {
        return codebreakerAttempt;
    }

    public JPanel getCodebreakerColors() {
        return codebreakerColors;
    }
  
}
