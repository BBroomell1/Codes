/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import static constants.Constants.MAX_PEGS;
import java.awt.Color;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Brandon
 */
public class Codebreaker implements ICodebreaker {

    private ArrayList<Color> codebreakerAttempt;

    /**
     * @return the codebreakerAttempt
     */
    public ArrayList<Color> getCodebreakerAttempt() {
        consoleAttempt();
        return codebreakerAttempt;
    }

    /**
     * @param codebreakerAttempt the codebreakerAttempt to set
     */
    public void setCodebreakerAttempt(ArrayList<Color> codebreakerAttempt) {
        this.codebreakerAttempt = codebreakerAttempt;
    }

    /**
     *
     */
    public Codebreaker() {
        codebreakerAttempt = new ArrayList<Color>();

    }

    @Override
    public void checkCode(ArrayList<Color> attempt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void consoleAttempt() {
        codebreakerAttempt.removeAll(codebreakerAttempt);
        Scanner input;
        input = new Scanner(System.in);
        int i = 0;

        System.out.println("Enter your colors from left to right \n" + "Use BLUE, BLACK, ORANGE, WHITE, YELLOW, RED, GREEN, PINK");
        do {
            String tempInput = input.next();
            String inputColor = tempInput.toUpperCase();

            if (("BLUE".equals(inputColor)) || ("BLACK".equals(inputColor)) || ("ORANGE".equals(inputColor)) || ("WHITE".equals(inputColor)) || ("YELLOW".equals(inputColor)) || ("RED".equals(inputColor)) || ("GREEN".equals(inputColor)) || ("PINK".equals(inputColor))) {
                
                    
                         System.out.println("The selected color was: \n" + inputColor);
                        codebreakerAttempt.add(Color.getColor(inputColor));
                        i++;
                        
                    
                    
               
                System.out.println("Enter next color.");
            }//END IF STATEMENT
            else
            {
                System.out.println("Invalid color choice, try again");
            }
        } while (i < MAX_PEGS); //END WHILE LOOP
    }//END METHOD

}//END CLASS CODEBREAKER
