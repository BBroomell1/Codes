/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import static constants.Constants.MAX_ATTEMPTS;
import java.awt.Color;
import java.util.ArrayList;

/**
 *
 * @author Brandon
 */
public class Game implements IGame{
    private int attempt;
    private Codebreaker codebreaker;
    private Codemaker codemaker;

    

   
    /**
     * @return the attempt
     */
    public int getAttempt() {
        return attempt;
    }

    /**
     * @param attempt the attempt to set
     */
    public void setAttempt(int attempt) {
        this.attempt = attempt;
    }

    /**
     * @return the codebreaker
     */
    public Codebreaker getCodebreaker() {
        return codebreaker;
    }

    /**
     * @param codebreaker the codebreaker to set
     */
    public void setCodebreaker(Codebreaker codebreaker) {
        this.codebreaker = codebreaker;
    }

    /**
     * @return the codemaker
     */
    public Codemaker getCodemaker() {
        return codemaker;
    }

    /**
     * @param codemaker the codemaker to set
     */
    public void setCodemaker(Codemaker codemaker) {
        this.codemaker = codemaker;
    }
    
    public Game(){
        codebreaker = new Codebreaker();
        codemaker = new Codemaker();
        play();
    }
    
    /**
     *
     */
    @Override
    public void play() {
        int i = 0;
        while((i < MAX_ATTEMPTS))
        {
            ArrayList<Color> tempColor = new ArrayList();
            tempColor = codebreaker.getCodebreakerAttempt();
            
            codemaker.checkAttemptedCode(tempColor);
            
            ArrayList<Color> response = new ArrayList();
            response = codemaker.getCodeMakerResponse();
            
            for(Color out: response)
            {
                System.out.println("Codemakers response");
                System.out.println(out);
            }
                
                i++;
        }
    }

}
