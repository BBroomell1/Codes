/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;


import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import static constants.Constants.codeColors;
import static constants.Constants.COLORS;
import static constants.Constants.MAX_PEGS;
/**
 *
 * @author Brandon
 */
public class Codemaker implements ICodemaker{
//VARIABLES
    private Set<Color> secretCode;
    private ArrayList<Color> codeMakerResponse;

    
   
    //GETTERS AND SETTERS
   /**
     * @return the secretCode
     */
    public Set<Color> getSecretCode() {
        return secretCode;
    }

    /**
     * @param secretCode the secretCode to set
     */
    public void setSecretCode(Set<Color> secretCode) {
        this.secretCode = secretCode;
    }

    /**
     * @return the codeMakerResponse
     */
    public ArrayList<Color> getCodeMakerResponse() {
        return codeMakerResponse;
    }

    /**
     * @param codeMakerResponse the codeMakerResponse to set
     */
    public void setCodeMakerResponse(ArrayList<Color> codeMakerResponse) {
        this.codeMakerResponse = codeMakerResponse;
    }

    
//CONSTRUCTOR
     public Codemaker() {
//INITIALIZE VARIABLES
        secretCode = new HashSet();
        codeMakerResponse = new ArrayList();
       
     
        generateSecretCode();
      
    }

    @Override
    public void generateSecretCode() {
//RANDOM INSTANCE
       Random rand = new Random();
//GENERATE 4 RANDOM COLORS AND ADD THEM TO secretCode 
     do{
         int number = rand.nextInt(COLORS);
         Color tempColor;
         tempColor = codeColors.get(number);
         secretCode.add(tempColor);
     }while(secretCode.size() < MAX_PEGS);
     
//PRINT OUT EACH COLOR USING AN ENHANCED FOR LOOP
     for(Color color: secretCode){
        System.out.println(color);
        }
    }
    @Override
    public void checkAttemptedCode(ArrayList<Color> attempt) {
        
/* I AM HAVING TROUBLE WITH THIS PART HERE, SPECIFICALLY CONVERTING THE SECRET CODE SET MEMBER
        VARIABLE TO AN ARRAYLIST OBJECT.
        */

        int redPegs = 0;
        int whitePegs = 0;
        ArrayList<Color> evalPegs = new ArrayList();
        ArrayList<Color> attempted = new ArrayList();
        attempted = attempt;
        ArrayList<Color> secret = new ArrayList();
        secret = (ArrayList) secretCode;
        
        System.out.println("Codemaker is checking codebreaker attempt");
        if(attempted.equals(secret))
        {
           redPegs = 4;
           whitePegs = 0;
           System.out.println("You Guessed IT!");
           System.out.println("Red Pegs: " + redPegs + " White Pegs: " + whitePegs);
        }
        
        for(int i = 0; i < MAX_PEGS; i++)
        {
            if(attempted.indexOf(i) == (secret.indexOf(i))) 
            {
                redPegs++;
                evalPegs.add(attempted.get(i));
                System.out.println("Found correct color in correct position!");
            }
        
        for(Color temp: attempted)
        {
            if(secret.contains(temp))
            {
                for(i = 0; i < MAX_PEGS; i++)
                {
                    if((attempted.indexOf(i) != secret.indexOf(i)) && (secret.contains(attempted.indexOf(i))) && (!evalPegs.contains(attempted.indexOf(i))))
                    {
                        whitePegs++;
                        evalPegs.add(temp);
                        System.out.println("Found Correct color in wrong position");
                    }
                }
            }
        }
            System.out.println("Red Pegs: " + redPegs + " White Pegs: " + whitePegs);
       
        }

    

     for(int i = 0; i < redPegs; i++)
        {
            codeMakerResponse.add(Color.RED);
        }
        
        for(int i = 0; i < whitePegs; i++)
        {
            codeMakerResponse.add(Color.WHITE);
        }
        
        for(Color response: codeMakerResponse)
        {
            System.out.print(response);
        }

    
    
    
    }
}//END CLASS
