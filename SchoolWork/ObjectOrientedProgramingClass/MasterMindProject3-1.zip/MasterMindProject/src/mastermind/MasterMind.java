// Brandon Broomell
// COP 3330 Fall 2017
// Date 9/17/2017

package mastermind;

import core.Game;
import javax.swing.JOptionPane;


public class MasterMind {

  
    public static void main(String[] args) {
        System.out.println("Welcome to MasterMind!");
        JOptionPane.showMessageDialog(null, "Let's Play Mastermind");
        
        Game game = new Game();
    }
    
}
