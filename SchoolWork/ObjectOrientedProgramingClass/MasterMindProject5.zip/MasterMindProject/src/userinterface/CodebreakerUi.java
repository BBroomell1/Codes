/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import static constants.Constants.codeColors;
import core.Codebreaker;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 *
 * @author Brandon
 */
public class CodebreakerUi {
    
    JPanel codebreakerAttempt;
    JPanel codebreakerColors;
    Codebreaker codebreaker;
    RoundButton[] buttons;
    RoundButton[][] attempts;
    
    public CodebreakerUi(Codebreaker codebreaker)
            {
                this.codebreaker = codebreaker;
                initComponents();
            }
    
    public void initComponents()
    {
        
        
    //CODEBREAKER ATTEMPT JPANEL 
    codebreakerAttempt = new JPanel();
        codebreakerAttempt.setMinimumSize(new Dimension(600,200));
        codebreakerAttempt.setPreferredSize(new Dimension(600,200));
        codebreakerAttempt.setBorder(BorderFactory.createTitledBorder("Codebreaker Attempt"));
        codebreakerAttempt.setLayout(new GridLayout(10, 4));
        attempts = new RoundButton[10][4];
        for(int i = 0; i < 10; i++)
        {
            for(int j = 0; j < 4; j++)
            {
                attempts[i][j] = new RoundButton();
                if(i != 9)
                {
                    attempts[i][j].setEnabled(false);
                }
                codebreakerAttempt.add(attempts[i][j]);
            }
        }
        
    //CODEBREAKER COLORS JPANEL 
    codebreakerColors = new JPanel();
        codebreakerColors.setMinimumSize(new Dimension(200,200));
        codebreakerColors.setPreferredSize(new Dimension(200,200));
        codebreakerColors.setBorder(BorderFactory.createTitledBorder("Codebreaker Colors"));
        codebreakerColors.setLayout(new FlowLayout());
        //Add the RoundButtons to the JPanel
        buttons = new RoundButton[8];
        for(int i = 0; i < 8; i++)
        {
            buttons[i] = new RoundButton();
            Color colorTemp = new Color(codeColors.indexOf(i));
            buttons[i].setBackground(colorTemp);
            buttons[i].putClientProperty("color", colorTemp);
            buttons[i].setToolTipText(colorTemp);
            
        codebreakerColors.add(buttons[i]);
        
        }
    }
    public JPanel getCodebreakerAttempt() {
        return codebreakerAttempt;
    }

    public JPanel getCodebreakerColors() {
        return codebreakerColors;
    }
  
}
